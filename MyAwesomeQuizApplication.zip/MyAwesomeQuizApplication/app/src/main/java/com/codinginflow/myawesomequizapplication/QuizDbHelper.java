package com.codinginflow.myawesomequizapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaPlayer;
import android.os.Build;
import android.support.annotation.RequiresApi;

import com.codinginflow.myawesomequizapplication.QuizContract.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MyAwesomeQuiz.db";
    private static final int DATABASE_VERSION = 10;
    private static QuizDbHelper instance;
    private SQLiteDatabase db;
    private QuizDbHelper(Context context) {
        super (context, DATABASE_NAME, null,DATABASE_VERSION);
    }
    public static synchronized QuizDbHelper getInstance(Context context){
        if (instance == null){
            instance = new QuizDbHelper (context.getApplicationContext ());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_CATRGORIES_TABLE = "CREATE TABLE " +
                CategoriesTable.TABLE_NAME + "( " +
                CategoriesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CategoriesTable.COLUME_NAME + " TEXT " +
                ")";
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuizContract.QuestionsTable.TABLE_NAME + " ( " +
                QuizContract.QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuizContract.QuestionsTable.COLUMN_QUESTION + " TEXT," +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionsTable.COLUMN_DIFFICULTY + " TEXT, " +
                QuestionsTable.COLUMN_CATEGORY_ID + " INTEGER, " +
                "FOREIGN KEY(" + QuestionsTable.COLUMN_CATEGORY_ID + ") REFERENCES " +
                CategoriesTable.TABLE_NAME + "(" + CategoriesTable._ID + ")" + "ON DELETE CASCADE" +
                ")";
        db.execSQL (SQL_CREATE_CATRGORIES_TABLE);
        db.execSQL (SQL_CREATE_QUESTIONS_TABLE);
        fillCategoriesTable();
        fillQuestionsTable();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL ("DROP TABLE IF EXISTS " + CategoriesTable.TABLE_NAME);
        db.execSQL ("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate (db);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure (db);
        db.setForeignKeyConstraintsEnabled(true);
    }
    private void fillCategoriesTable(){
        Category c1 = new Category ("Python");
        addCategory(c1);
        Category c2 = new Category ("Android");
        addCategory(c2);
        Category c3 = new Category ("Java");
        addCategory(c3);
        Category c4 = new Category ("C");
        addCategory(c4);
    }
    private void addCategory(Category category){
        ContentValues cv = new ContentValues();
        cv.put (CategoriesTable.COLUME_NAME, category.getName ());
        db.insert (CategoriesTable.TABLE_NAME,null,cv);
    }

    private void fillQuestionsTable(){
        Question q1 = new Question ("All Keywords in Python are in",
                "UPPER CASE", "lower case", "None Of the mentioned",3,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q1);
        Question q2 = new Question ("What is the return type of function id?",
                "int", "Float", "boolean",1,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q2);
        Question q3 = new Question ("What is the following data types is not supported in python",
                "String", "Numbers", "Slice",3,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q3);
        Question q4 = new Question ("Select reserved keywords in python",
                "else", "inport", "All of the above",3,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q4);
        Question q5 = new Question ("The format function, when applied on string returns",
                "list", "str", "int",2,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q5);
        Question q6 = new Question ("which one of the following is not a python's predefined datatype",
                "Class", "tuple", "Dictionary",1,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q6);
        Question q7 = new Question ("Which of the following has more precedence",
                "/", "+", "()",3,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q7);
        Question q8 = new Question ("Operators with the same precedence are evaluated in which manner?",
                "Left to Right", "Right to left", "Can,t say",1,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q8);
        Question q9 = new Question ("What arithmetic operators cannot be used with strings?",
                "+", "*", "-",3,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q9);
        Question q10 = new Question ("What is called a function is defined inside a class",
                "Module", "Method", "Another Function",2,
                Question.DIFFICULTY_EASY,Category.PYTHON);
        addQuestion (q10);

        Question q11 = new Question ("Android is developed By",
                "Apple", "Google", "Android Inc",3,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q11);
        Question q12 = new Question ("Android,Easy: A is correct",
                "Chrome", "Open-Source Webkit", "Safari",2,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q12);
        Question q13 = new Question ("Android is Based On which Kernel",
                "Linux", "Windows", "Mac",1,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q13);
        Question q14 = new Question ("What are the Layout available in android",
                "Linear Layout", "Table Layout", "Both 1 & 2",3,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q14);
        Question q15 = new Question ("In Which Directory XML Layout Files Are Stored",
                "/src", "/res/layout", "/res/value",2,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q15);
        Question q16 = new Question ("What is the name of the program that convert java byte code into Dalvik byte code?",
                "Dex compiler", "Mobile interpretive Compiler", "Dalvik Converter",1,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q16);
        Question q17 = new Question ("Android is based on Linux for the following reason",
                "Security", "Networking", "Both 1 & 2",3,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q17);
        Question q18 = new Question ("What Activity methods you use to retrieve a reference to an Android view bu using the id attribute of a resource XML?",
                "findViewByReference(int id)", "findViewByID(int id)", "findViewByID(String id)",2,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q18);
        Question q19 = new Question ("DVM is developed By",
                "Linus Torvald", "Dennis Ritchie", "Dan Bornstein",3,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q19);
        Question q20 = new Question ("OHA stand for",
                "Open Handset Alliance", "Open Host Application", "Open Handset Application",1,
                Question.DIFFICULTY_EASY,Category.ANDROID);
        addQuestion (q20);

        Question q31 = new Question ("Which of the following can be operands of arithmetic operator",
                "Numeric", "Character", "Both 1 & 2",3,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q31);
        Question q32 = new Question ("decrement operator -- decrease the value of variable bu what number",
                "1", "2", "3",1,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q32);
        Question q33 = new Question ("Which of these operator is used to aalocate memory to array variable in Java",
                "new", "malloc", "alloc",1,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q33);
        Question q34 = new Question ("Which of these is not bitwise operator",
                "&=", "<=", "!=",2,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q34);
        Question q35 = new Question ("Which right shift operator preserves the sign of the value",
                "<<", ">>", "<<=",2,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q35);
        Question q36 = new Question ("Which keyword is used by the method to refer to the object that invoked it?",
                "abstract", "catch", "this",3,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q36);
        Question q37 = new Question ("Which method is define only one in the java program?",
                "main method", "static method", "private method",1,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q37);
        Question q38 = new Question ("Which of the method of String class is used to obtain character at specified index? ",
                "char()", "charAt()", "Charat()",2,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q38);
        Question q39 = new Question ("Which of this cannot be declared as Static",
                "class", "method", "object",3,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q39);
        Question q40 = new Question ("Java is developed By",
                "James Gosling", "Sun Microsystem", "Chris Warth",3,
                Question.DIFFICULTY_EASY,Category.JAVA);
        addQuestion (q40);
        Question q41 = new Question ("Which of the following is a logical AND operator",
                "&&", "!", "&",1,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q41);
        Question q42 = new Question ("Which statement are print \n on the screen",
                "printf('\\n')", "printf('n')", "print('\n')",3,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q42);
        Question q43 = new Question ("C Programming was created in year...",
                "1982", "1972", "1976",2,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q43);
        Question q44 = new Question ("C Programming was created ar .... by Dennis Ritchie",
                "L&T Laboratory", "MIT Laboratory", "AT&T Bell Laboratory",3,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q44);
        Question q45 = new Question ("Array is a example of .... type memory allocation.",
                "Run Time", "Compile Time", "Both 1 & 2",2,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q45);
        Question q46 = new Question ("Syntax of array is",
                "array_name = new Array[size]", "data_type array_name[size]", "[size] = array_name",2,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q46);
        Question q47 = new Question ("Libray function getch() belongs to which header file?",
                "conio.h", "stdio.h", "sdio.h",3,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q47);
        Question q48 = new Question ("Smallest element of the array is called as......",
                "Middle Bound", "Range", "Lower Bound",3,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q48);
        Question q49 = new Question ("Pointer is special kind of variable which is used to stored ... of the variable",
                "Address", "Variable Name", "Value",1,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q49);
        Question q50 = new Question ("* is called as....",
                "Address Operator", "value at Operator", "Scope Resolution Operator",2,
                Question.DIFFICULTY_EASY,Category.C);
        addQuestion (q50);
        Question q51 = new Question ("print 9/2",
                "4.5", "4.0", "4",3,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q51);
        Question q52 = new Question ("which function overloads the >> operator",
                "more()", "none of these", "gt()",2,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q52);
        Question q53 = new Question ("i = 0 while i < 3: print i i++ print i+1",
                "error", "0 1 2 3 4 5", "0 2 1 3 2 4",3,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q53);
        Question q54 = new Question (" what data type is the object below? L = [1, 23,'hello', 1]",
                "Tuple", "List", "Array",2,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q54);
        Question q55 = new Question ("How to create Frame in python?",
                "Frame = Frame()", "Frame = new.window()", "Frame = window.new()",1,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q55);
        Question q56 = new Question ("In python we can create a popup menu. select thr code to display a popup menu?",
                "Menu.post()", "Menu.display()", "Menu.post(250,250)",3,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q56);
        Question q57 = new Question ("what is the maximum possible length odf an identifier?",
                "32 character", "79 Character", "None of the above",3,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q57);
        Question q58 = new Question (" Which Method is used for adds the item to the end of the list  ",
                "list.append(item)", "list.count(item)", "list.index(item)",1,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q58);
        Question q59 = new Question ("Syntax for defining the tuple in python",
                "<tuple_name> = value1,..valueN", "<tuple_name> = (value1,..valueN)", "(tuple_name) = value1,..valueN",2,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q59);
        Question q60 = new Question ("Python is ",
                "high-level", "object-orientated", "all of the above",3,
                Question.DIFFICULTY_MEDIUM,Category.PYTHON);
        addQuestion (q60);
        Question q61 = new Question ("What is android",
                "Android is a stack of software's for mobility", "Virtual Machine", "Google Mobile device name",1,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q61);
        Question q62 = new Question ("What is the application class in android",
                "A class that can create only an object", "Anonymous class", "Base class for all classes",3,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q62);

        Question q63 = new Question ("What is an interface in android",
                "Interface is a class", "Interface acts as a bridge between class and the outside world", "Interface is a layout file",2,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q63);

        Question q64 = new Question ("Once installed on a device, each Android application lives in .....",
                "Security", "external memory", "device memory",1,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q64);

        Question q65 = new Question ("Which are the screen sizes in Android?",
                "small", "normal", "All are the mentioned",3,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q65);

        Question q66 = new Question ("Definition of Loader is",
                "Loaders make it easy to synchronously load data in an activity or fragment", "Loaders does not make easy to asynchronously load data in an activity or fragment", "Loaders make it easy to asynchronously load data in an activity or fragment.",3,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q66);

        Question q67 = new Question ("Which piece of code used in Android is not open source",
                "wifi? driver", "Audio driver", "Power management",1,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q67);

        Question q68 = new Question ("What file responsible for glueing everything together, explaning what the application consists of",
                "layout file", "manifest file", "String file",2,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q68);

        Question q69 = new Question ("The XML file that contains all the text that your application uses",
                "stack.xml", "text.xml", "string.xml",3,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q69);

        Question q70 = new Question ("Which of this are not onn of the three main components of the APK",
                "Resource", "WebKit", "Dalvik Executable",2,
                Question.DIFFICULTY_MEDIUM,Category.ANDROID);
        addQuestion (q70);

        Question q81 = new Question ("Which of the following statements are incorrect?",
                "static method are only call by other static method only", "static method must only access static data", "when object of the class declared,each object contains's its own copy of static variables",3,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q81);
        Question q82 = new Question ("which of these methods must be made static?",
                "main()", "run()", "finalize()",3,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q82);
        Question q83 = new Question ("Which of these is an incorrect array declaration",
                "int [] arr = new int[5]", "int arr[] = new int[5]", "int arr[] = int {5} new",3,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q83);
        Question q84 = new Question ("Which of these statement is incorrect ",
                "Every class must contain a main() method", "main() method must be made public", "Applets de not require a main() method at all",1,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q84);
        Question q85 = new Question ("what is the process of defining more than one method in a class differentiate by method signature",
                "Function overloading", "function overriding", "None mentioned",1,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q85);
        Question q86 = new Question ("which of these keywords are used to defined an abstract class",
                "abst", "abstract", "Abstract",2,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q86);
        Question q87 = new Question ("which of these class is superclass of string and stringBuffer class?",
                "java.util", "java.lang", "ArrayList",2,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q87);
        Question q88 = new Question ("which of these constructors is used to create an empty String object",
                "string()", "String(void)", "String(0)",3,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q88);
        Question q89 = new Question ("which of the following is a valid declaration of an object of class Box?",
                "Box obj = new Box();", "Box obj = new Box;", "obj = new Box();",1,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q89);
        Question q90 = new Question ("class main_class{ public static void main(String args[]){int x = 9; if(x==9){int x = 8;System.out.println(x);}}}",
                "8", "Compilation error", "Runtime error",3,
                Question.DIFFICULTY_MEDIUM,Category.JAVA);
        addQuestion (q90);
        Question q91 = new Question ("All keywords in c are in?",
                "Lower case letters", "Upper case letters", "Camel case letters",1,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q91);
        Question q92 = new Question ("Which of the following cannot be variable name in c",
                "Volatile", "True", "export",1,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q92);
        Question q93 = new Question ("comment on the following?",
                "You cannot change the value pointed by ptr", "You can change the pointer value", "Both 1 & 2",1,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q93);
        Question q94 = new Question ("Which of the following are the correctb syntax to send the array as a parameter to function?",
                "func(*array)", "func(&array)", "func(array)",3,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q94);
        Question q95 = new Question ("The value obtained in the function is given back to main by using ..... keyword?",
                "return", "static", "new",1,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q95);
        Question q96 = new Question ("What is the return type of function sqrt()?",
                "float", "int", "double",3,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q96);
        Question q97 = new Question ("Which among the following is NOT a logical or relational operator",
                "=", "!=", "==",1,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q97);
        Question q98 = new Question ("int main(){ int x=1,y=0,z=3;x>y?printf('%d',z):return z;}",
                "true", "1", "Compile time error",3,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q98);
        Question q99 = new Question ("\b is used for",
                "New line", "Backspace", "Form feed",2,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q99);
        Question q100 = new Question ("The scope of the automatic variable is",
                "within the block it appears", "within the block of the block is appears", "both 1 & 2",3,
                Question.DIFFICULTY_MEDIUM,Category.C);
        addQuestion (q100);
        Question q101 = new Question ("Which of the following  is not a feature of python",
                "Easy to learn and use", "Interactive Mode", "None of the mentioned",3,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q101);
        Question q102 = new Question (" A literals refers to the ",
                "enclosing text in the quotes", "fixed value that directly appears in the program", "collection of consecutive character",2,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q102);
        Question q103 = new Question ("min() returns",
                "largest value among supplied argument", "negative value of the argument value", "smallest value among supplied argument",3,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q103);
        Question q104 = new Question ("which method is use to flush the internal buffer",
                "file.flush()", "file.tell", "file.read()",1,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q104);
        Question q105 = new Question ("Syntax for creating new Directory",
                "os.mkdir('newdir')", "newdir = os.mkdir", "os.mkdir = newdir",1,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q105);
        Question q106 = new Question ("Python has two basic mode namely as",
                "normal script mode & Interactive Mode", "IDLE & PyCharm", "None of the Mentioned",1,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q106);
        Question q107 = new Question ("Which is a Identity operator in python",
                "OR", "==", "is not",3,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q107);
        Question q108 = new Question ("Syntax of range() Function is",
                "range(begin, stop, step)", "range (begin, end, step)", "range = (range, begin, stop)",2,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q108);
        Question q109 = new Question ("What is the output of print 0.1 + 0.2 == 0.3?",
                "true", "Error", "false",3,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q109);
        Question q110 = new Question ("Which are the following function are built in function in python",
                "seed()", "print()", "sqrt()",2,
                Question.DIFFICULTY_HARD,Category.PYTHON);
        addQuestion (q110);
        Question q111 = new Question ("Creating UI in Android require careful use of....",
                "java and SQL", "XML and C++", "XML and java",3,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q111);
        Question q112 = new Question ("Which among the following are part of Application layer of Android Architecture",
                "Contact", "Browser", "All of these",3,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q112);
        Question q113 = new Question ("The Emulator is identical to running a real phone EXCEPT when emulating/simulating what?",
                "Telephony", "Sensors", "Application",2,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q113);
        Question q114 = new Question ("What does the .apk extention stand for?",
                "Android package", "Application program kit", "Application Package",3,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q114);
        Question q115 = new Question ("The emulated device for android",
                "Runs the same code base as the acual device, all the way down to the machine layer", "Runs the same code base as the actual device ,however at a higher level", "An imaginary machine built on the hopes and dreams of baby elephants",1,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q115);
        Question q116 = new Question ("What built-in database is Android shipped with?",
                "Apache", "SQLite", "MySQL",2,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q116);
        Question q117 = new Question ("When did Google purchase Android?",
                "2005", "2010", "2008",1,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q117);
        Question q118 = new Question ("What is an Activity",
                "A component that runs in the background without any interface", "A message sent among building blocks", "A single screen the user sees on the device at one time",3,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q118);
        Question q119 = new Question ("Which of the following should be used to save the unsaved data and release  being used by an Android application?",
                "Activity.onStop()", "Activity.onDestroy", "Activity.onShutdown()",2,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q119);
        Question q120 = new Question ("Which of the following would you have to include in your project to use the SimpleAdapter class",
                "import.android.content", "import android.database", "import android.widget",3,
                Question.DIFFICULTY_HARD,Category.ANDROID);
        addQuestion (q120);

        Question q134 = new Question ("Which of the following statement is correct",
                "Public method is accessible to all other classes in the hierarchy", "Public method can only be called by object of its class", "public method can be accessed by calling object of the public class",1,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q134);
        Question q135 = new Question ("What is the range of short data type in java",
                "-128 to 127", "-32768 to 32767", "None of above",2,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q135);
        Question q136 = new Question ("class increment{ public static void main(String args[]){ int g = 3;System.out.println(++g * 8)",
                "33", "25", "32",3,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q136);
        Question q137 = new Question ("Which of these can not be use variable name in java",
                "number", "keyword", "identifier",2,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q137);
        Question q138 = new Question ("which keyword is used to inherit the class",
                "super", "this", "extends",3,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q138);
        Question q139 = new Question ("Which of these class is superclass of string and StringBuffer class",
                "java.lang", "ArrayList", "java.util",1,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q139);
        Question q140 = new Question ("Which of these methods of class StringBuffer is to used to extract a substring from String object",
                "subString()", "SubString", "Substring()",1,
                Question.DIFFICULTY_HARD,Category.JAVA);
        addQuestion (q140);
        Question q141 = new Question ("Which is an indirection operator among the following",
                "->", "&", "*",3,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q141);
        Question q142 = new Question ("In order to access any element of an array if the position of element is known, Time complexity will be equal to ...",
                "o(1)", "o(n-1)", "O(n)",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q142);
        Question q143 = new Question ("Array can be consider as set of elements stored in consecutive memory locations but having....",
                "Same Data Type", "Same Scope", "Different Data Type",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q143);
        Question q144 = new Question ("Pointer is special lind of variable which is used to stored .... of the variable",
                "Address", "Dara Type", "Value",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q144);
        Question q145 = new Question ("what is the size of int data type",
                "32 bit", "8- bit", "Depend on the system compiler",3,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q145);
        Question q146 = new Question ("Automatic variable are stored in",
                "stack", "heap", "register",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q146);
        Question q147 = new Question ("void main(){int x} here x is?",
                "static variable", "Automatic variable", "global variable",2,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q147);
        Question q148 = new Question ("void main() { int a = -5; int k = (a++,++a); printf('%d\n',k);}",
                "-3", "-5", "4",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q148);
        Question q149 = new Question ("Which data type is most suitable for storing a number 65000 in a 32- bit system?",
                "int", "short", "double",2,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q149);
        Question q150 = new Question ("# include is called as .....",
                "Preprocessor directive", "File inclusion directive", "Inclusion directive",1,
                Question.DIFFICULTY_HARD,Category.C);
        addQuestion (q150);



    }
    private void addQuestion(Question question){
        ContentValues cv = new ContentValues ();
        cv.put(QuestionsTable.COLUMN_QUESTION,question.getQuestion ());
        cv.put(QuestionsTable.COLUMN_OPTION1,question.getOption1 ());
        cv.put(QuestionsTable.COLUMN_OPTION2,question.getOption2 ());
        cv.put(QuestionsTable.COLUMN_OPTION3,question.getOption3 ());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR,question.getAnswerNr ());
        cv.put(QuestionsTable.COLUMN_DIFFICULTY,question.getDifficulty ());
        cv.put (QuestionsTable.COLUMN_CATEGORY_ID, question.getCategoryID ());
        db.insert (QuestionsTable.TABLE_NAME,null,cv);
    }
    public List<Category> getAllCategories(){
        List<Category> categoryList = new ArrayList<> ();
        db = getReadableDatabase ();
        Cursor c = db.rawQuery ("SELECT * FROM  " + CategoriesTable.TABLE_NAME,null);
        if (c.moveToFirst ()){
            do {
                Category category = new Category ();
                category.setId (c.getInt (c.getColumnIndex (CategoriesTable._ID)));
                category.setName (c.getString (c.getColumnIndex (CategoriesTable.COLUME_NAME)));
                categoryList.add(category);
            }while (c.moveToNext ());
        }
        c.close ();
        return categoryList;
    }
    public ArrayList<Question> getAllQuestion(){
        ArrayList <Question> questionList = new ArrayList<> ();
        db = getReadableDatabase ();
        Cursor c = db.rawQuery ("SELECT * FROM " + QuestionsTable.TABLE_NAME,null);
        if (c.moveToFirst ()){
            do {
                Question question = new Question ();
                question.setId (c.getInt (c.getColumnIndex (QuestionsTable._ID)));
                question.setQuestion (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_QUESTION)));
                question.setOption1 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION1)));
                question.setOption2 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION2)));
                question.setOption3 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNr (c.getInt (c.getColumnIndex (QuestionsTable.COLUMN_ANSWER_NR)));
                question.setDifficulty (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID (c.getColumnIndex (QuestionsTable.COLUMN_CATEGORY_ID));
                questionList.add (question);
            }while (c.moveToNext ());
        }
        c.close ();
        return questionList;
    }
    public ArrayList<Question> getQuestion(int categoryID, String difficulty){
        ArrayList <Question> questionList = new ArrayList<> ();
        db = getReadableDatabase ();
        String selection = QuestionsTable.COLUMN_CATEGORY_ID + " = ? " +
                " AND " + QuestionsTable.COLUMN_DIFFICULTY + " = ? ";
        String[] selectionArgs = new String[]{String.valueOf (categoryID), difficulty};
        Cursor c = db.query (
                QuestionsTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (c.moveToFirst ()){
            do {
                Question question = new Question ();
                question.setId (c.getInt (c.getColumnIndex (QuestionsTable._ID)));
                question.setQuestion (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_QUESTION)));
                question.setOption1 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION1)));
                question.setOption2 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION2)));
                question.setOption3 (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_OPTION3)));
                question.setAnswerNr (c.getInt (c.getColumnIndex (QuestionsTable.COLUMN_ANSWER_NR)));
                question.setDifficulty (c.getString (c.getColumnIndex (QuestionsTable.COLUMN_DIFFICULTY)));
                question.setCategoryID (c.getColumnIndex (QuestionsTable.COLUMN_CATEGORY_ID));
                questionList.add (question);
            }while (c.moveToNext ());
        }
        c.close ();
        return questionList;
    }
}


